const fs = require('fs');
const path = require('path');

// ============================================================
// DATA
// ============================================================
const ODDS = { milspec: 0.7992, restricted: 0.1598, classified: 0.032, covert: 0.0064, gold: 0.0026 };
const SITE = 'https://cs2caseodds.com';

const CASES = [
  { slug: 'revolution-case', name: 'Revolution Case', year: 2023 },
  { slug: 'recoil-case', name: 'Recoil Case', year: 2022 },
  { slug: 'dreams-nightmares-case', name: 'Dreams & Nightmares Case', year: 2022 },
  { slug: 'fracture-case', name: 'Fracture Case', year: 2020 },
  { slug: 'snakebite-case', name: 'Snakebite Case', year: 2021 },
  { slug: 'clutch-case', name: 'Clutch Case', year: 2018 },
  { slug: 'prisma-2-case', name: 'Prisma 2 Case', year: 2020 },
  { slug: 'prisma-case', name: 'Prisma Case', year: 2019 },
  { slug: 'danger-zone-case', name: 'Danger Zone Case', year: 2018 },
  { slug: 'horizon-case', name: 'Horizon Case', year: 2018 },
  { slug: 'spectrum-2-case', name: 'Spectrum 2 Case', year: 2017 },
  { slug: 'spectrum-case', name: 'Spectrum Case', year: 2017 },
  { slug: 'glove-case', name: 'Glove Case', year: 2016 },
  { slug: 'gamma-2-case', name: 'Gamma 2 Case', year: 2016 },
  { slug: 'gamma-case', name: 'Gamma Case', year: 2016 },
  { slug: 'chroma-3-case', name: 'Chroma 3 Case', year: 2016 },
  { slug: 'chroma-2-case', name: 'Chroma 2 Case', year: 2015 },
  { slug: 'chroma-case', name: 'Chroma Case', year: 2015 },
  { slug: 'falchion-case', name: 'Falchion Case', year: 2015 },
  { slug: 'shadow-case', name: 'Shadow Case', year: 2015 },
  { slug: 'revolver-case', name: 'Revolver Case', year: 2015 },
  { slug: 'wildfire-case', name: 'Wildfire Case', year: 2016 },
  { slug: 'operation-hydra-case', name: 'Operation Hydra Case', year: 2017 },
  { slug: 'operation-phoenix-case', name: 'Operation Phoenix Case', year: 2014 },
  { slug: 'operation-breakout-case', name: 'Operation Breakout Case', year: 2014 },
  { slug: 'operation-vanguard-case', name: 'Operation Vanguard Case', year: 2014 },
  { slug: 'operation-bravo-case', name: 'Operation Bravo Case', year: 2013 },
  { slug: 'huntsman-case', name: 'Huntsman Case', year: 2014 },
  { slug: 'winter-offensive-case', name: 'Winter Offensive Case', year: 2013 },
  { slug: 'cs-weapon-case', name: 'CS:GO Weapon Case', year: 2013 },
  { slug: 'cs-weapon-case-2', name: 'CS:GO Weapon Case 2', year: 2013 },
  { slug: 'cs-weapon-case-3', name: 'CS:GO Weapon Case 3', year: 2014 },
  { slug: 'esports-2013-case', name: 'eSports 2013 Case', year: 2013 },
  { slug: 'esports-2013-winter-case', name: 'eSports 2013 Winter Case', year: 2013 },
  { slug: 'esports-2014-summer-case', name: 'eSports 2014 Summer Case', year: 2014 },
  { slug: 'operation-riptide-case', name: 'Operation Riptide Case', year: 2021 },
  { slug: 'shattered-web-case', name: 'Shattered Web Case', year: 2019 },
  { slug: 'broken-fang-case', name: 'Broken Fang Case', year: 2020 },
  { slug: 'cs20-case', name: 'CS20 Case', year: 2019 },
  { slug: 'kilowatt-case', name: 'Kilowatt Case', year: 2024 },
  { slug: 'gallery-case', name: 'Gallery Case', year: 2024 },
];

const KNIFE_COUNTS = [10, 25, 50, 100, 250, 500, 1000];

// ============================================================
// HELPERS
// ============================================================
function knifeProb(n) { return (1 - Math.pow(1 - ODDS.gold, n)) * 100; }
function pct(v) { return (v * 100).toFixed(2) + '%'; }
function expected(n, rate) { return (n * rate).toFixed(2); }

function nav(current) {
  const links = [
    ['/', 'Home'], ['/case-odds.html', 'Case Odds'], ['/knife-odds.html', 'Knife Odds'],
    ['/case-calculator.html', 'Calculator'], ['/expected-value.html', 'Expected Value'],
    ['/cs2-case-roi.html', 'ROI'], ['/best-cases-to-open.html', 'Best Cases']
  ];
  return links.map(([href, label]) =>
    `<a href="${href}"${href === current ? ' style="color:var(--text);background:var(--surface2)"' : ''}>${label}</a>`
  ).join('');
}

function head(title, desc, canonical, extra = '') {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>${title}</title>
<meta name="description" content="${desc}">
<link rel="canonical" href="${SITE}${canonical}">
<meta property="og:title" content="${title}"><meta property="og:description" content="${desc}">
<meta property="og:type" content="website"><meta property="og:url" content="${SITE}${canonical}">
<meta name="twitter:card" content="summary"><meta name="twitter:title" content="${title}">
<link rel="stylesheet" href="/css/style.css">
${extra}
</head>
<body>`;
}

function header(current) {
  return `<header><nav>${nav(current)}</nav></header>`;
}

function footer() {
  return `<footer><div class="container"><p>CS2 Case Odds Calculator — Accurate drop rates for every CS2 case.</p><p style="margin-top:8px"><a href="https://example.com" rel="nofollow">Open CS2 cases instantly at CSGOLuck</a></p></div></footer>`;
}

function breadcrumb(items) {
  const html = items.map((it, i) => i < items.length - 1 ? `<a href="${it[1]}">${it[0]}</a>` : `<span>${it[0]}</span>`).join('<span>›</span>');
  const jsonld = { "@context":"https://schema.org", "@type":"BreadcrumbList", "itemListElement": items.map((it, i) => ({ "@type":"ListItem", "position": i+1, "name": it[0], "item": i < items.length - 1 ? SITE + it[1] : undefined }))};
  return `<div class="breadcrumbs">${html}</div><script type="application/ld+json">${JSON.stringify(jsonld)}</script>`;
}

function oddsTable() {
  return `<table class="odds-table">
<thead><tr><th>Rarity</th><th>Probability</th><th>Odds</th></tr></thead>
<tbody>
<tr><td class="rarity-milspec">Mil-Spec (Blue)</td><td>79.92%</td><td class="odds-table">1 in 1.25</td></tr>
<tr><td class="rarity-restricted">Restricted (Purple)</td><td>15.98%</td><td>1 in 6.26</td></tr>
<tr><td class="rarity-classified">Classified (Pink)</td><td>3.20%</td><td>1 in 31.25</td></tr>
<tr><td class="rarity-covert">Covert (Red)</td><td>0.64%</td><td>1 in 156.25</td></tr>
<tr><td class="rarity-gold">Exceedingly Rare (Gold)</td><td>0.26%</td><td>1 in 384.6</td></tr>
</tbody></table>`;
}

function calculator() {
  return `<div class="calc-box">
<h3>Case Odds Calculator</h3>
<div class="calc-row"><div class="calc-field"><label for="case-count">Number of Cases</label><input type="number" id="case-count" min="1" max="100000" value="100"></div></div>
<div class="result-grid" id="calc-results"></div>
</div>
<script src="/js/calc.js"></script>`;
}

function evCalculator() {
  return `<div class="calc-box">
<h3>Expected Value Calculator</h3>
<div class="calc-row">
<div class="calc-field"><label for="ev-case-price">Case Price ($)</label><input type="number" id="ev-case-price" step="0.01" value="0.50"></div>
<div class="calc-field"><label for="ev-key-price">Key Price ($)</label><input type="number" id="ev-key-price" step="0.01" value="2.49"></div>
</div>
<div class="result-grid" id="ev-results"></div>
</div>
<script src="/js/calc.js"></script>`;
}

function probTable(counts) {
  let rows = counts.map(n => {
    const p = knifeProb(n);
    return `<tr><td>${n}</td><td>${p.toFixed(2)}%</td><td>${(100 - p).toFixed(2)}%</td><td>${expected(n, ODDS.covert)}</td></tr>`;
  }).join('');
  return `<table><thead><tr><th>Cases</th><th>Knife Chance</th><th>No Knife</th><th>Expected Coverts</th></tr></thead><tbody>${rows}</tbody></table>`;
}

function caseLinks(exclude) {
  const subset = CASES.filter(c => c.slug !== exclude).slice(0, 10);
  return `<div class="link-grid">${subset.map(c => `<a href="/case/${c.slug}.html">${c.name} Odds</a>`).join('')}</div>`;
}

function internalLinks() {
  return `<div class="link-grid">
<a href="/">Home</a><a href="/case-odds.html">Case Odds Guide</a><a href="/knife-odds.html">Knife Odds</a>
<a href="/case-calculator.html">Calculator</a><a href="/expected-value.html">Expected Value</a>
</div>`;
}

function faqSchema(faqs) {
  const schema = { "@context":"https://schema.org", "@type":"FAQPage", "mainEntity": faqs.map(f => ({ "@type":"Question", "name": f[0], "acceptedAnswer": { "@type":"Answer", "text": f[1] }}))};
  return `<script type="application/ld+json">${JSON.stringify(schema)}</script>`;
}

function writePage(filepath, content) {
  const dir = path.dirname(filepath);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(filepath, content);
}

const OUT = __dirname;

// ============================================================
// INDEX PAGE
// ============================================================
function buildIndex() {
  const faqs = [
    ['What are the odds of getting a knife in CS2?', 'The odds of getting a knife or gloves from any CS2 case are 0.26%, which is approximately 1 in 384.6 cases.'],
    ['What are CS2 case odds?', 'All CS2 cases share the same drop rates: 79.92% Mil-Spec, 15.98% Restricted, 3.20% Classified, 0.64% Covert, and 0.26% Exceedingly Rare (knife/gloves).'],
    ['How many cases for a knife in CS2?', 'On average, you need to open approximately 385 cases to get one knife drop, though due to probability each case is an independent event.'],
  ];
  const html = `${head('CS2 Case Odds Calculator — Real Drop Rates for Every Case', 'Free CS2 case odds calculator. See exact drop rates for knives, coverts, and all rarities. Calculate probability across any number of cases.', '/index.html', faqSchema(faqs))}
${header('/')}
<main><div class="container">
<div class="hero">
<h1>CS2 Case Odds Calculator</h1>
<p>Calculate exact drop probabilities for every CS2 case. See your real chances of getting a knife, covert, classified, or any rarity across any number of cases.</p>
</div>

${calculator()}

<div class="stat-row">
<div class="stat-card"><div class="num rarity-gold">0.26%</div><div class="desc">Knife/Gloves</div></div>
<div class="stat-card"><div class="num rarity-covert">0.64%</div><div class="desc">Covert</div></div>
<div class="stat-card"><div class="num rarity-classified">3.20%</div><div class="desc">Classified</div></div>
<div class="stat-card"><div class="num" style="color:var(--accent)">384.6</div><div class="desc">Cases per Knife</div></div>
</div>

<h2>CS2 Case Drop Rates</h2>
<p>Every CS2 case uses identical rarity drop rates set by Valve. These odds apply to all cases regardless of release date, price, or contents. The probabilities are fixed and do not change based on how many cases you have opened previously. Each case opening is an independent event.</p>
${oddsTable()}
<p>These odds mean that for every 10,000 cases opened across all players, approximately 7,992 will contain a Mil-Spec item, 1,598 a Restricted, 320 a Classified, 64 a Covert, and 26 a knife or pair of gloves. Individual results vary significantly due to the nature of probability.</p>

<h2>How CS2 Case Probability Works</h2>
<p>CS2 case openings follow a Bernoulli distribution. Each opening is independent, meaning previous results have no effect on future outcomes. There is no pity system, no streak protection, and no hidden mechanics that increase your odds over time. Opening 384 cases without getting a knife does not increase the probability of getting one on the 385th case.</p>
<p>The probability of getting at least one knife in N cases is calculated using the complement formula: P = 1 - (1 - 0.0026)^N. This means opening 100 cases gives you approximately a <a href="/knife-chance-100-cases.html">22.87% chance</a> of getting at least one knife, while opening <a href="/knife-chance-500-cases.html">500 cases</a> gives you roughly a 72.73% chance. Even opening <a href="/knife-chance-1000-cases.html">1,000 cases</a> does not guarantee a knife — the probability is about 92.56%.</p>

<h2>Understanding Expected Value</h2>
<p>The expected value of opening CS2 cases is consistently negative. On average, players receive back approximately 30-40% of the cost of opening a case (case price plus key price combined). This means for every dollar spent, you can expect to receive roughly $0.35 in return value on average. High-value drops like knives, rare patterns, and StatTrak coverts can dramatically shift individual outcomes, but over large sample sizes the expected loss converges toward the mean.</p>
<p>Visit our <a href="/expected-value.html">expected value calculator</a> to calculate the precise EV for any case based on current market prices.</p>

<h2>Knife Probability by Number of Cases</h2>
${probTable([10, 25, 50, 100, 250, 500, 1000])}
<p>See the full breakdown on our <a href="/knife-odds.html">knife odds page</a>, or use the <a href="/case-calculator.html">calculator</a> for any custom number.</p>

<h2>Browse Cases</h2>
<p>View detailed odds, probability tables, and expected value for each individual CS2 case:</p>
<div class="link-grid">
${CASES.slice(0, 20).map(c => `<a href="/case/${c.slug}.html">${c.name}</a>`).join('')}
</div>
<p style="margin-top:12px"><a href="/case-odds.html">View all ${CASES.length} cases →</a></p>

<h2>Frequently Asked Questions</h2>
${faqs.map(f => `<div class="faq-item"><h3>${f[0]}</h3><p>${f[1]}</p></div>`).join('')}

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'index.html'), html);
}

// ============================================================
// CASE ODDS MASTER PAGE
// ============================================================
function buildCaseOdds() {
  const html = `${head('CS2 Case Odds — Complete Drop Rate Guide for Every Rarity', 'Complete CS2 case odds guide. Exact drop rates for Mil-Spec, Restricted, Classified, Covert, and knife/gloves. All cases use identical probabilities.', '/case-odds.html')}
${header('/case-odds.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Case Odds']])}
<h1>CS2 Case Odds — Complete Drop Rate Guide</h1>
<p>Every CS2 case uses the same fixed drop rates. These probabilities are set by Valve and apply universally to all weapon cases regardless of their release date, price, or the skins they contain. Understanding these odds is essential for making informed decisions about case openings.</p>

${oddsTable()}

<h2>How Drop Rates Work in CS2</h2>
<p>CS2 uses a weighted random number generator to determine the rarity of each item you receive from a case. When you open a case, the system generates a random number and maps it to one of the five rarity tiers based on the probability weights listed above. The visual spinner animation you see is purely cosmetic and does not represent the actual selection process.</p>
<p>These odds are consistent across all cases. Opening a Revolution Case, a Clutch Case, or any other weapon case gives you the exact same 0.26% chance of receiving a knife or pair of gloves. The only difference between cases is which specific skins are available within each rarity tier.</p>
<p>Each case opening is statistically independent. The outcome of one opening has absolutely no influence on the next. There is no pity timer, no escalating odds, and no mechanism that rewards players who have opened many cases without receiving a rare item.</p>

<h2>Rarity Tier Breakdown</h2>
<h3>Mil-Spec (Blue) — 79.92%</h3>
<p>Mil-Spec items make up the vast majority of case drops. With nearly 80% probability, most case openings will result in a blue-tier skin. These items typically have the lowest market value, often selling for less than the cost of a case key. Read more on our <a href="/milspec-odds.html">Mil-Spec odds page</a>.</p>

<h3>Restricted (Purple) — 15.98%</h3>
<p>Restricted items drop roughly once every six cases. While more valuable than Mil-Spec, most Restricted skins still sell below key price. Certain popular skins in this tier can hold decent value. See our <a href="/restricted-odds.html">Restricted odds page</a> for details.</p>

<h3>Classified (Pink) — 3.20%</h3>
<p>Classified items are the first rarity tier where individual skins commonly exceed key price. With a 3.20% drop rate, you can expect approximately one Classified per 31 cases. These drops often generate excitement but should not be relied upon for profit. Visit our <a href="/classified-odds.html">Classified odds page</a>.</p>

<h3>Covert (Red) — 0.64%</h3>
<p>Covert items drop once per approximately 156 cases. These are the highest-tier weapon skins and frequently sell for significant amounts on the Steam Market. StatTrak versions of Covert skins are especially valuable. Learn more on our <a href="/covert-odds.html">Covert odds page</a>.</p>

<h3>Exceedingly Rare (Gold) — 0.26%</h3>
<p>The gold tier contains knives and gloves. At 0.26% probability, these items drop roughly once per 385 cases. They represent the most valuable possible drops and are the primary reason many players open cases. See our comprehensive <a href="/knife-odds.html">knife odds analysis</a>.</p>

<h2>All CS2 Cases</h2>
<div class="link-grid">
${CASES.map(c => `<a href="/case/${c.slug}.html">${c.name}</a>`).join('')}
</div>

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'case-odds.html'), html);
}

// ============================================================
// KNIFE ODDS PAGE
// ============================================================
function buildKnifeOdds() {
  const faqs = [
    ['What is the chance of getting a knife in CS2?', 'The base probability is 0.26% per case, which equals approximately 1 in 384.6 cases.'],
    ['How many cases for 50% knife chance?', `You need approximately ${Math.ceil(Math.log(0.5) / Math.log(1 - ODDS.gold))} cases for a 50% cumulative probability of getting at least one knife.`],
    ['Can you get a knife on first case?', 'Yes. Every case has an independent 0.26% chance. Your first case has the same odds as your thousandth.'],
  ];
  const html = `${head('CS2 Knife Odds — Probability of Getting a Knife from Cases', 'What are the real odds of getting a knife in CS2? 0.26% per case. Calculate your exact probability across any number of cases.', '/knife-odds.html', faqSchema(faqs))}
${header('/knife-odds.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Knife Odds']])}
<h1>CS2 Knife Odds — Complete Probability Guide</h1>
<p>The probability of receiving a knife or pair of gloves from any CS2 case is exactly 0.26%, which translates to approximately 1 in 384.6 cases. This page provides a complete analysis of knife drop probability across different numbers of case openings.</p>

<div class="stat-row">
<div class="stat-card"><div class="num rarity-gold">0.26%</div><div class="desc">Per Case</div></div>
<div class="stat-card"><div class="num rarity-gold">1 in 385</div><div class="desc">Average</div></div>
<div class="stat-card"><div class="num rarity-gold">${Math.ceil(Math.log(0.5) / Math.log(1 - ODDS.gold))}</div><div class="desc">Cases for 50%</div></div>
</div>

${calculator()}

<h2>Knife Probability Table</h2>
<p>The probability of getting at least one knife in N cases follows the formula: P = 1 - (1 - 0.0026)^N. This accounts for the cumulative probability across multiple independent trials.</p>
${probTable([1, 5, 10, 25, 50, 100, 150, 200, 250, 300, 385, 500, 750, 1000])}

<h2>Understanding Knife Probability</h2>
<p>Many players misunderstand how probability works with case openings. The statement that a knife drops once per 385 cases on average does not mean you are guaranteed a knife after opening 385 cases. It means that across a very large number of trials, the average number of cases between knife drops converges toward 385.</p>
<p>After opening 385 cases, your cumulative probability of having received at least one knife is approximately 63.3%. This means roughly one in three players who open 385 cases will not have received a knife. Even after 1,000 cases, approximately 7.4% of players will still not have seen a knife drop.</p>
<p>This is because each case opening is independent. The 385th case has exactly the same 0.26% probability as the first. There is no accumulation of luck, no hidden counter, and no pity system that guarantees a drop after a certain number of attempts.</p>

<h2>Knife Probability by Case Count</h2>
<div class="link-grid">
${KNIFE_COUNTS.map(n => `<a href="/knife-chance-${n}-cases.html">Knife chance in ${n} cases →</a>`).join('')}
</div>

<h2>Frequently Asked Questions</h2>
${faqs.map(f => `<div class="faq-item"><h3>${f[0]}</h3><p>${f[1]}</p></div>`).join('')}

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'knife-odds.html'), html);
}

// ============================================================
// RARITY PAGES (covert, classified, restricted, milspec)
// ============================================================
function buildRarityPage(rarity, color, rate, odds1in, title, slug) {
  const html = `${head(title, `Complete guide to ${rarity} drop rates in CS2 cases. ${pct(rate)} probability per case opening.`, `/${slug}.html`)}
${header()}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Case Odds', '/case-odds.html'], [rarity]])}
<h1>${title}</h1>
<p>${rarity} items have a drop probability of ${pct(rate)} in every CS2 case, which equals approximately 1 in ${odds1in} cases. This rate is identical across all weapon cases.</p>

<div class="stat-row">
<div class="stat-card"><div class="num" style="color:${color}">${pct(rate)}</div><div class="desc">Per Case</div></div>
<div class="stat-card"><div class="num" style="color:${color}">1 in ${odds1in}</div><div class="desc">Average</div></div>
</div>

<h2>Expected ${rarity} Items by Cases Opened</h2>
<table><thead><tr><th>Cases</th><th>Expected ${rarity}</th><th>Probability of 1+</th></tr></thead>
<tbody>${[10, 25, 50, 100, 250, 500, 1000].map(n => {
  const exp = (n * rate).toFixed(2);
  const prob = ((1 - Math.pow(1 - rate, n)) * 100).toFixed(2);
  return `<tr><td>${n}</td><td>${exp}</td><td>${prob}%</td></tr>`;
}).join('')}</tbody></table>

<h2>How ${rarity} Drops Work</h2>
<p>When you open a CS2 case, the game engine randomly selects a rarity tier. If the ${rarity.toLowerCase()} tier is selected, the game then randomly chooses one of the ${rarity.toLowerCase()} skins available in that specific case. Each skin within the tier has an equal chance of being selected, though StatTrak versions have a roughly 10% chance of being applied to any drop.</p>
<p>The value of ${rarity.toLowerCase()} items varies enormously depending on the specific skin, its float value, any applied stickers, and whether it has StatTrak technology. Some ${rarity.toLowerCase()} skins are worth very little while others command significant prices on the Steam Market.</p>

${calculator()}

<h2>Complete Odds Table</h2>
${oddsTable()}

${internalLinks()}
${caseLinks('')}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, `${slug}.html`), html);
}

// ============================================================
// CALCULATOR PAGES
// ============================================================
function buildCalcPage(title, desc, slug, defaultVal, extraContent) {
  const html = `${head(title, desc, `/${slug}.html`)}
${header('/case-calculator.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Calculator']])}
<h1>${title}</h1>
<p>${desc}</p>
${calculator()}
${extraContent}
${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, `${slug}.html`), html);
}

// ============================================================
// INDIVIDUAL CASE PAGES
// ============================================================
function buildCasePage(c) {
  const faqs = [
    [`What are the odds in ${c.name}?`, `${c.name} uses the standard CS2 drop rates: 79.92% Mil-Spec, 15.98% Restricted, 3.20% Classified, 0.64% Covert, and 0.26% knife/gloves.`],
    [`What is the chance of a knife in ${c.name}?`, `The chance of a knife or gloves from ${c.name} is 0.26% per case opening, the same as every other CS2 case.`],
    [`Is ${c.name} worth opening?`, `Like all CS2 cases, the expected value of opening ${c.name} is negative. On average you receive back roughly 30-40% of the opening cost. Individual results vary widely.`],
  ];
  const html = `${head(`${c.name} Odds — CS2 Drop Rates, Knife Chance & Calculator`, `${c.name} odds and drop rates. 0.26% knife chance, 0.64% covert, 3.20% classified. Calculate probability for any number of cases.`, `/case/${c.slug}.html`, faqSchema(faqs))}
${header()}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Case Odds', '/case-odds.html'], [c.name]])}
<h1>${c.name} Odds</h1>
<p>The ${c.name} was released in ${c.year} and uses the standard CS2 drop rates shared by all weapon cases. Below you will find the complete odds breakdown, probability tables, a calculator, and frequently asked questions.</p>

<h2>${c.name} Drop Rates</h2>
${oddsTable()}

<h2>${c.name} Knife Probability</h2>
<p>The chance of receiving a knife or gloves from the ${c.name} is exactly 0.26% per opening. On average, you would need to open approximately 385 ${c.name} cases to receive one knife drop. The probability of getting at least one knife across different numbers of cases is shown below.</p>
${probTable([10, 50, 100, 500])}

<h2>${c.name} Calculator</h2>
<p>Enter the number of ${c.name} cases you plan to open to see expected drops across all rarities:</p>
${calculator()}

<h2>${c.name} Expected Value</h2>
<p>The expected return from opening ${c.name} depends on current market prices for the skins it contains. Use our <a href="/expected-value/${c.slug}.html">expected value calculator for ${c.name}</a> to compute the precise EV based on current case and key prices.</p>

<h2>Is ${c.name} Worth Opening?</h2>
<p>From a pure expected value perspective, no CS2 case is profitable to open on average. The ${c.name} follows this pattern. The expected return is approximately 30-40% of the cost of opening. However, the ${c.name} contains some desirable skins that hold value well, which can make individual results highly variable. The possibility of receiving a high-value knife or rare pattern means some players will profit significantly while the majority will not.</p>
<p>If you choose to open ${c.name} cases, do so for entertainment rather than as an investment strategy. Set a budget you are comfortable losing entirely, as that is the most likely outcome from a mathematical perspective.</p>

<h2>Frequently Asked Questions</h2>
${faqs.map(f => `<div class="faq-item"><h3>${f[0]}</h3><p>${f[1]}</p></div>`).join('')}

<h2>Other Cases</h2>
${caseLinks(c.slug)}

<h2>More Resources</h2>
${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'case', `${c.slug}.html`), html);
}

// ============================================================
// KNIFE CHANCE PAGES
// ============================================================
function buildKnifeChancePage(n) {
  const prob = knifeProb(n);
  const noKnife = (100 - prob).toFixed(2);
  const faqs = [
    [`What is the chance of getting a knife in ${n} CS2 cases?`, `The probability of getting at least one knife in ${n} CS2 cases is ${prob.toFixed(2)}%. This is calculated using P = 1 - (1 - 0.0026)^${n}.`],
    [`Is ${n} cases enough for a knife?`, `${n} cases gives you a ${prob.toFixed(2)}% chance. ${prob > 50 ? 'You have better than even odds but it is not guaranteed.' : 'You are more likely to not get a knife than to get one.'}`],
  ];
  const html = `${head(`Chance of Getting a Knife in ${n} CS2 Cases — ${prob.toFixed(2)}%`, `Calculate your probability of getting a knife in ${n} CS2 cases using real drop rates. ${prob.toFixed(2)}% chance with exact calculations.`, `/knife-chance-${n}-cases.html`, faqSchema(faqs))}
${header('/knife-odds.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Knife Odds', '/knife-odds.html'], [`${n} Cases`]])}
<h1>Chance of Getting a Knife in ${n} CS2 Cases</h1>
<p>If you open ${n} CS2 cases, you have a <strong>${prob.toFixed(2)}%</strong> chance of receiving at least one knife or pair of gloves. This means there is a ${noKnife}% chance you will open ${n} cases and receive no knife at all.</p>

<div class="stat-row">
<div class="stat-card"><div class="num rarity-gold">${prob.toFixed(2)}%</div><div class="desc">Knife Chance</div></div>
<div class="stat-card"><div class="num">${noKnife}%</div><div class="desc">No Knife</div></div>
<div class="stat-card"><div class="num">${expected(n, ODDS.covert)}</div><div class="desc">Expected Coverts</div></div>
<div class="stat-card"><div class="num">${expected(n, ODDS.classified)}</div><div class="desc">Expected Classifieds</div></div>
</div>

<h2>Expected Drops from ${n} Cases</h2>
<table><thead><tr><th>Rarity</th><th>Expected Count</th><th>Probability</th></tr></thead>
<tbody>
<tr><td class="rarity-milspec">Mil-Spec</td><td>${expected(n, ODDS.milspec)}</td><td>79.92% each</td></tr>
<tr><td class="rarity-restricted">Restricted</td><td>${expected(n, ODDS.restricted)}</td><td>15.98% each</td></tr>
<tr><td class="rarity-classified">Classified</td><td>${expected(n, ODDS.classified)}</td><td>3.20% each</td></tr>
<tr><td class="rarity-covert">Covert</td><td>${expected(n, ODDS.covert)}</td><td>0.64% each</td></tr>
<tr><td class="rarity-gold">Knife/Gloves</td><td>${expected(n, ODDS.gold)}</td><td>0.26% each</td></tr>
</tbody></table>

<h2>How This Is Calculated</h2>
<p>The probability of getting at least one knife in ${n} cases uses the complement formula: P = 1 - (1 - 0.0026)^${n} = 1 - ${Math.pow(1 - ODDS.gold, n).toFixed(6)} = ${(prob / 100).toFixed(4)} = ${prob.toFixed(2)}%.</p>
<p>This formula works because it calculates the probability of NOT getting a knife ${n} times in a row (which is (1 - 0.0026)^${n}), and then subtracts that from 1 to get the probability of getting at least one knife.</p>
${prob < 50 ? `<p>With ${n} cases, you are more likely to receive no knife than to receive one. You would need approximately ${Math.ceil(Math.log(0.5) / Math.log(1 - ODDS.gold))} cases for a 50% chance.</p>` : `<p>With ${n} cases, you have better than even odds of receiving at least one knife. However, a ${noKnife}% chance of no knife is still substantial and should be expected as a realistic outcome.</p>`}

<h2>Calculator</h2>
${calculator()}

<h2>Compare Other Amounts</h2>
<div class="link-grid">
${KNIFE_COUNTS.filter(k => k !== n).map(k => `<a href="/knife-chance-${k}-cases.html">${k} cases → ${knifeProb(k).toFixed(2)}%</a>`).join('')}
</div>

<h2>Frequently Asked Questions</h2>
${faqs.map(f => `<div class="faq-item"><h3>${f[0]}</h3><p>${f[1]}</p></div>`).join('')}

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, `knife-chance-${n}-cases.html`), html);
}

// ============================================================
// EXPECTED VALUE PAGES
// ============================================================
function buildEVMaster() {
  const html = `${head('CS2 Case Expected Value — Is Opening Cases Profitable?', 'Calculate the expected value of opening CS2 cases. Understand profitability, average returns, and why the house always wins.', '/expected-value.html')}
${header('/expected-value.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Expected Value']])}
<h1>CS2 Case Expected Value Guide</h1>
<p>Expected value (EV) measures the average outcome of an action over many repetitions. For CS2 cases, EV tells you how much money you can expect to receive back for each case you open. Understanding EV is crucial for making informed decisions about case openings.</p>

${evCalculator()}

<h2>What Is Expected Value?</h2>
<p>Expected value is a mathematical concept that calculates the average result of a random event if it were repeated infinitely. For CS2 case openings, the EV is calculated by multiplying the probability of each possible outcome by its value and summing all results.</p>
<p>In practical terms, the EV of a CS2 case is the average amount of money you receive back per opening. If a case costs $2.99 to open (case + key) and the EV is $1.05, you lose $1.94 on average per opening. Over 100 openings, you would expect to spend $299 and receive approximately $105 in return.</p>

<h2>Why EV Is Always Negative</h2>
<p>The expected value of every CS2 case is negative because the vast majority of drops (roughly 96%) are Mil-Spec and Restricted items worth far less than the opening cost. The rare high-value drops (coverts, knives) are too infrequent to offset the consistent losses on common drops. On average, players receive back approximately 30-40% of their opening cost.</p>
<p>This negative EV is by design. Valve profits from the difference between opening costs and average return values. Case openings function as a form of entertainment gambling rather than an investment.</p>

<h2>Case Expected Values</h2>
<div class="link-grid">
${CASES.slice(0, 20).map(c => `<a href="/expected-value/${c.slug}.html">${c.name} EV</a>`).join('')}
</div>

<h2>Factors That Affect EV</h2>
<p>Several factors influence the expected value of a specific case. The prices of individual skins within the case are the primary driver, particularly the value of the covert and classified tier skins. Cases containing highly sought-after skins in these tiers will have better EV than cases with unpopular skins. The price of the case itself also matters — cheaper cases have less negative EV since the opening cost is lower.</p>
<p>Market conditions change constantly. A case might have relatively good EV when a new popular skin drives prices up, but that EV deteriorates as supply increases and prices fall. Always check current market prices before calculating EV.</p>

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'expected-value.html'), html);
}

function buildCaseEVPage(c) {
  const faqs = [
    [`Is ${c.name} profitable to open?`, `On average, no. Like all CS2 cases, the expected return from ${c.name} is approximately 30-40% of the opening cost. Individual results vary widely due to rare high-value drops.`],
    [`What is the expected return of ${c.name}?`, `The expected return depends on current skin prices. Use the calculator above to compute EV based on current case and key prices.`],
  ];
  const html = `${head(`${c.name} Expected Value — Is It Worth Opening?`, `Calculate the expected value of opening ${c.name}. See average return, profit/loss, and ROI based on current prices.`, `/expected-value/${c.slug}.html`, faqSchema(faqs))}
${header('/expected-value.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Expected Value', '/expected-value.html'], [c.name]])}
<h1>${c.name} Expected Value</h1>
<p>Calculate whether the ${c.name} is worth opening based on current market prices. Enter the case price and key price below to see the expected return, profit or loss, and ROI percentage.</p>

${evCalculator()}

<h2>Understanding ${c.name} EV</h2>
<p>The expected value of the ${c.name} depends on the current market prices of all skins it contains, weighted by their drop probabilities. Since approximately 80% of drops are Mil-Spec items worth very little, the EV is heavily influenced by the value of the rarer items — particularly the covert and knife/gloves tier.</p>
<p>When calculating EV, remember that the total cost per opening includes both the case price and the key price ($2.49). Even if a case sells for $0.03 on the Steam Market, the total opening cost is still $2.52, making the effective EV calculation require a relatively high average return to break even.</p>

<h2>${c.name} Drop Rates</h2>
${oddsTable()}

<h2>Expected Drops per 100 Cases</h2>
<table><thead><tr><th>Rarity</th><th>Expected in 100 Cases</th></tr></thead>
<tbody>
<tr><td class="rarity-milspec">Mil-Spec</td><td>~80 items</td></tr>
<tr><td class="rarity-restricted">Restricted</td><td>~16 items</td></tr>
<tr><td class="rarity-classified">Classified</td><td>~3.2 items</td></tr>
<tr><td class="rarity-covert">Covert</td><td>~0.64 items</td></tr>
<tr><td class="rarity-gold">Knife/Gloves</td><td>~0.26 items</td></tr>
</tbody></table>

<h2>Frequently Asked Questions</h2>
${faqs.map(f => `<div class="faq-item"><h3>${f[0]}</h3><p>${f[1]}</p></div>`).join('')}

<h2>Other Case EV Pages</h2>
<div class="link-grid">
${CASES.filter(x => x.slug !== c.slug).slice(0, 6).map(x => `<a href="/expected-value/${x.slug}.html">${x.name} EV</a>`).join('')}
</div>
${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'expected-value', `${c.slug}.html`), html);
}

// ============================================================
// ROI PAGES
// ============================================================
function buildROIMaster() {
  const html = `${head('CS2 Case ROI — Return on Investment Guide', 'Understand CS2 case ROI. Calculate return on investment for opening cases with real probability data.', '/cs2-case-roi.html')}
${header('/cs2-case-roi.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['ROI']])}
<h1>CS2 Case ROI — Return on Investment Guide</h1>
<p>ROI (Return on Investment) measures the percentage return relative to your total spending. For CS2 cases, ROI is consistently negative, meaning players lose money on average. This page explains how ROI works for case openings and provides tools to calculate your expected returns.</p>

${evCalculator()}

<h2>What Is Case ROI?</h2>
<p>ROI is calculated as: ROI = ((Return - Cost) / Cost) × 100%. If you spend $100 opening cases and receive $35 in skin value, your ROI is -65%. This means you lost 65 cents for every dollar spent. Across the entire CS2 player base, the average ROI for case openings is approximately -60% to -70%.</p>

<h2>Why ROI Is Negative</h2>
<p>CS2 case ROI is negative because the system is designed to generate revenue for Valve and the skin economy. The 79.92% probability of receiving a Mil-Spec item worth far less than the opening cost ensures that the average return is well below the cost. Only the rare high-value drops from the covert and gold tiers can push an individual session into profitable territory.</p>

<h2>ROI by Number of Cases</h2>
<p>The more cases you open, the more closely your results will converge toward the expected negative ROI. In small sample sizes (10-50 cases), variance is high and some players will profit. In large sample sizes (500+ cases), nearly all players will show a significant net loss.</p>
${probTable([10, 50, 100, 500, 1000])}

<h2>Case ROI Pages</h2>
<div class="link-grid">
${CASES.slice(0, 20).map(c => `<a href="/roi/${c.slug}.html">${c.name} ROI</a>`).join('')}
</div>

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'cs2-case-roi.html'), html);
}

function buildCaseROIPage(c) {
  const html = `${head(`${c.name} ROI — Return on Investment Calculator`, `Calculate the ROI of opening ${c.name} in CS2. Expected returns, probability tables, and profitability analysis.`, `/roi/${c.slug}.html`)}
${header('/cs2-case-roi.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['ROI', '/cs2-case-roi.html'], [c.name]])}
<h1>${c.name} ROI Calculator</h1>
<p>Calculate your expected return on investment for opening ${c.name} cases. Enter current market prices to see the projected ROI across different numbers of cases.</p>

${evCalculator()}

<h2>${c.name} Expected Returns</h2>
<table><thead><tr><th>Cases</th><th>Knife Chance</th><th>Expected Coverts</th><th>Expected Classifieds</th></tr></thead>
<tbody>${[10, 50, 100, 500].map(n => `<tr><td>${n}</td><td>${knifeProb(n).toFixed(2)}%</td><td>${expected(n, ODDS.covert)}</td><td>${expected(n, ODDS.classified)}</td></tr>`).join('')}</tbody></table>

<h2>ROI Analysis</h2>
<p>The ROI of opening ${c.name} depends on the current prices of its contents. Cases with high-value covert and knife skins have relatively better (less negative) ROI, while cases with low-value contents have worse ROI. On average, expect an ROI between -60% and -70% over a large number of openings.</p>
<p>Short-term variance means that small batches of cases can produce wildly different ROI figures. A single knife drop in 50 cases could produce positive ROI, while 200 cases without a knife will show deep negative ROI.</p>

<h2>Other Case ROI Pages</h2>
<div class="link-grid">
${CASES.filter(x => x.slug !== c.slug).slice(0, 6).map(x => `<a href="/roi/${x.slug}.html">${x.name} ROI</a>`).join('')}
</div>
${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'roi', `${c.slug}.html`), html);
}

// ============================================================
// COMPARISON PAGES
// ============================================================
function buildComparisonPages() {
  // Case Comparison
  let html = `${head('CS2 Case Comparison — Compare Drop Rates and Value', 'Compare CS2 cases side by side. All cases share the same drop rates but differ in skin value and expected returns.', '/case-comparison.html')}
${header()}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Case Comparison']])}
<h1>CS2 Case Comparison</h1>
<p>All CS2 weapon cases share identical drop rate probabilities. The difference between cases lies in the specific skins they contain and the market value of those skins. This page helps you compare cases to make informed decisions.</p>

<h2>All Cases Share These Odds</h2>
${oddsTable()}

<h2>Key Comparison Factors</h2>
<p>Since drop rates are identical, the factors that differentiate cases are: the market value of covert skins, the value of classified skins, the desirability of knife finishes available, the case price on the Steam Market, and the overall demand for the case contents. Newer cases tend to have lower case prices due to higher supply, while discontinued or rare cases command premium prices.</p>

<h2>All CS2 Cases</h2>
<div class="link-grid">
${CASES.map(c => `<a href="/case/${c.slug}.html">${c.name} (${c.year})</a>`).join('')}
</div>
${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'case-comparison.html'), html);

  // Best Cases
  html = `${head('Best CS2 Cases to Open in 2024 — Ranked by Value', 'Which CS2 cases are the best to open? Compare expected value, knife chances, and skin desirability across all cases.', '/best-cases-to-open.html')}
${header('/best-cases-to-open.html')}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Best Cases']])}
<h1>Best CS2 Cases to Open</h1>
<p>While no CS2 case has a positive expected value on average, some cases offer better value than others based on the desirability and market price of their contents. This page ranks cases by overall value proposition to help you make the most informed decision if you choose to open cases.</p>

<h2>How We Rank Cases</h2>
<p>Case ranking considers several factors: the total value of covert skins, the value of classified and restricted tier skins, the desirability of available knife finishes, the case price, and overall market demand. Cases with expensive covert skins and desirable knife options offer relatively better (less negative) expected value.</p>

<h2>Important Disclaimer</h2>
<p>All CS2 cases have negative expected value. The average player will lose money opening any case. These rankings identify which cases lose less money on average, not which cases are profitable. If your goal is to make money, buying skins directly from the market is always more cost-effective than opening cases.</p>

<h2>Browse All Cases</h2>
<div class="link-grid">
${CASES.map(c => `<a href="/case/${c.slug}.html">${c.name}</a>`).join('')}
</div>

<h2>Expected Value by Case</h2>
<div class="link-grid">
${CASES.slice(0, 15).map(c => `<a href="/expected-value/${c.slug}.html">${c.name} EV</a>`).join('')}
</div>

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'best-cases-to-open.html'), html);

  // Most Profitable
  html = `${head('Most Profitable CS2 Cases — EV Ranked', 'Find the most profitable CS2 cases to open based on expected value analysis and current market prices.', '/most-profitable-cases.html')}
${header()}
<main><div class="container">
${breadcrumb([['Home', '/'], ['Most Profitable Cases']])}
<h1>Most Profitable CS2 Cases</h1>
<p>Profitability in CS2 case opening is relative — all cases have negative expected value on average. This page identifies which cases have the least negative EV, making them the relatively best options if you choose to open cases.</p>

<h2>Understanding Case Profitability</h2>
<p>A case is considered relatively profitable when its average return is closer to the opening cost. Cases with high-value coverts and desirable knife finishes tend to have better EV because the rare drops carry more value. However, since these rare drops occur at the same 0.64% (covert) and 0.26% (knife) rates across all cases, the day-to-day experience of opening any case is dominated by the same 80% Mil-Spec drops.</p>

<h2>Compare Case EV</h2>
<div class="link-grid">
${CASES.map(c => `<a href="/expected-value/${c.slug}.html">${c.name} EV</a>`).join('')}
</div>

${internalLinks()}
</div></main>
${footer()}
</body></html>`;
  writePage(path.join(OUT, 'most-profitable-cases.html'), html);
}

// ============================================================
// SPECIFIC CALCULATOR PAGES (100, 500, 1000)
// ============================================================
function buildSpecificCalcPages() {
  [100, 500, 1000].forEach(n => {
    const prob = knifeProb(n);
    buildCalcPage(
      `CS2 Case Calculator — ${n} Cases`,
      `Calculate expected drops and knife probability for ${n} CS2 case openings. ${prob.toFixed(2)}% knife chance.`,
      `${n}-cases`,
      n,
      `<h2>Expected Results from ${n} Cases</h2>
<table><thead><tr><th>Rarity</th><th>Expected Count</th></tr></thead>
<tbody>
<tr><td class="rarity-milspec">Mil-Spec</td><td>${expected(n, ODDS.milspec)}</td></tr>
<tr><td class="rarity-restricted">Restricted</td><td>${expected(n, ODDS.restricted)}</td></tr>
<tr><td class="rarity-classified">Classified</td><td>${expected(n, ODDS.classified)}</td></tr>
<tr><td class="rarity-covert">Covert</td><td>${expected(n, ODDS.covert)}</td></tr>
<tr><td class="rarity-gold">Knife/Gloves</td><td>${expected(n, ODDS.gold)}</td></tr>
</tbody></table>
<div class="stat-row">
<div class="stat-card"><div class="num rarity-gold">${prob.toFixed(2)}%</div><div class="desc">Knife Chance in ${n}</div></div>
<div class="stat-card"><div class="num">${(100 - prob).toFixed(2)}%</div><div class="desc">No Knife in ${n}</div></div>
</div>
<p>Opening ${n} cases gives you a ${prob.toFixed(2)}% cumulative probability of receiving at least one knife or pair of gloves. ${prob > 50 ? 'While the odds are in your favour, there is still a significant ' + (100-prob).toFixed(2) + '% chance of no knife.' : 'You are more likely to not receive a knife than to receive one.'}</p>
${caseLinks('')}`
    );
  });
}

// ============================================================
// SITEMAP & ROBOTS
// ============================================================
function buildSitemap() {
  const urls = [
    '/index.html', '/case-odds.html', '/knife-odds.html', '/case-calculator.html',
    '/knife-calculator.html', '/expected-value.html', '/cs2-case-roi.html',
    '/case-comparison.html', '/best-cases-to-open.html', '/most-profitable-cases.html',
    '/covert-odds.html', '/classified-odds.html', '/restricted-odds.html', '/milspec-odds.html',
    '/100-cases.html', '/500-cases.html', '/1000-cases.html',
  ];
  KNIFE_COUNTS.forEach(n => urls.push(`/knife-chance-${n}-cases.html`));
  CASES.forEach(c => {
    urls.push(`/case/${c.slug}.html`);
    urls.push(`/expected-value/${c.slug}.html`);
    urls.push(`/roi/${c.slug}.html`);
  });

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(u => `<url><loc>${SITE}${u}</loc></url>`).join('\n')}
</urlset>`;
  writePage(path.join(OUT, 'sitemap.xml'), xml);
  writePage(path.join(OUT, 'robots.txt'), `User-agent: *\nAllow: /\n\nSitemap: ${SITE}/sitemap.xml`);
}

// ============================================================
// BUILD ALL
// ============================================================
console.log('Building CS2 Case Odds site...');
buildIndex();
buildCaseOdds();
buildKnifeOdds();
buildRarityPage('Covert', '#eb4b4b', ODDS.covert, '156.25', 'CS2 Covert Odds — Red Skin Drop Rate Guide', 'covert-odds');
buildRarityPage('Classified', '#d32ce6', ODDS.classified, '31.25', 'CS2 Classified Odds — Pink Skin Drop Rate Guide', 'classified-odds');
buildRarityPage('Restricted', '#8847ff', ODDS.restricted, '6.26', 'CS2 Restricted Odds — Purple Skin Drop Rate Guide', 'restricted-odds');
buildRarityPage('Mil-Spec', '#4b69ff', ODDS.milspec, '1.25', 'CS2 Mil-Spec Odds — Blue Skin Drop Rate Guide', 'milspec-odds');

// Calculator pages
buildCalcPage('CS2 Case Calculator — Calculate Expected Drops', 'Free CS2 case odds calculator. Enter any number of cases to see expected drops across all rarities and knife probability.', 'case-calculator', 100, `<h2>How the Calculator Works</h2><p>This calculator uses the official CS2 drop rates to compute expected outcomes. Enter any number of cases and see the expected number of items at each rarity tier, plus your cumulative probability of receiving at least one knife.</p><h2>Formula</h2><p>Expected items = Number of cases × Drop rate. Knife probability = 1 - (1 - 0.0026)^N.</p>${caseLinks('')}`);
buildCalcPage('CS2 Knife Calculator — Knife Probability by Cases', 'Calculate your probability of getting a knife in any number of CS2 cases. Uses real 0.26% drop rate.', 'knife-calculator', 100, `<h2>Knife Probability Formula</h2><p>P(at least one knife) = 1 - (1 - 0.0026)^N, where N is the number of cases opened.</p>${probTable(KNIFE_COUNTS)}<div class="link-grid">${KNIFE_COUNTS.map(n => `<a href="/knife-chance-${n}-cases.html">${n} cases</a>`).join('')}</div>`);
buildSpecificCalcPages();

// Case pages
CASES.forEach(c => buildCasePage(c));

// Knife chance pages
KNIFE_COUNTS.forEach(n => buildKnifeChancePage(n));

// EV pages
buildEVMaster();
CASES.forEach(c => buildCaseEVPage(c));

// ROI pages
buildROIMaster();
CASES.forEach(c => buildCaseROIPage(c));

// Comparison pages
buildComparisonPages();

// Sitemap & robots
buildSitemap();

// Count
const countFiles = (dir) => {
  let count = 0;
  fs.readdirSync(dir, { withFileTypes: true }).forEach(f => {
    if (f.isDirectory()) count += countFiles(path.join(dir, f.name));
    else if (f.name.endsWith('.html')) count++;
  });
  return count;
};
console.log(`✓ Built ${countFiles(OUT)} HTML pages`);
console.log('✓ Sitemap generated');
console.log('✓ Build complete!');
