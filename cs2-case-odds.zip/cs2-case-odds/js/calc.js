// CS2 Case Odds - Canonical Probabilities
const ODDS = {
  milspec: 0.7992,
  restricted: 0.1598,
  classified: 0.032,
  covert: 0.0064,
  gold: 0.0026
};

const LABELS = {
  milspec: 'Mil-Spec',
  restricted: 'Restricted',
  classified: 'Classified',
  covert: 'Covert',
  gold: 'Exceedingly Rare (Knife/Gloves)'
};

function calcExpected(n) {
  return {
    milspec: (n * ODDS.milspec).toFixed(2),
    restricted: (n * ODDS.restricted).toFixed(2),
    classified: (n * ODDS.classified).toFixed(3),
    covert: (n * ODDS.covert).toFixed(4),
    gold: (n * ODDS.gold).toFixed(4),
    knifeProb: ((1 - Math.pow(1 - ODDS.gold, n)) * 100).toFixed(2),
    covertProb: ((1 - Math.pow(1 - ODDS.covert, n)) * 100).toFixed(2)
  };
}

function initCalc(inputId, resultsId) {
  const input = document.getElementById(inputId);
  const results = document.getElementById(resultsId);
  if (!input || !results) return;

  function update() {
    const n = parseInt(input.value) || 0;
    if (n < 1) { results.innerHTML = '<p style="color:var(--text2);text-align:center">Enter number of cases above</p>'; return; }
    const r = calcExpected(n);
    results.innerHTML = `
      <div class="result-item"><div class="val" style="color:#4b69ff">${r.milspec}</div><div class="lbl">Mil-Spec</div></div>
      <div class="result-item"><div class="val" style="color:#8847ff">${r.restricted}</div><div class="lbl">Restricted</div></div>
      <div class="result-item"><div class="val" style="color:#d32ce6">${r.classified}</div><div class="lbl">Classified</div></div>
      <div class="result-item"><div class="val" style="color:#eb4b4b">${r.covert}</div><div class="lbl">Covert</div></div>
      <div class="result-item gold"><div class="val">${r.gold}</div><div class="lbl">Knife/Gloves</div></div>
      <div class="result-item green"><div class="val">${r.knifeProb}%</div><div class="lbl">Knife Chance</div></div>
    `;
  }

  input.addEventListener('input', update);
  update();
}

function initEVCalc(caseInputId, keyInputId, resultsId) {
  const caseInput = document.getElementById(caseInputId);
  const keyInput = document.getElementById(keyInputId);
  const results = document.getElementById(resultsId);
  if (!caseInput || !keyInput || !results) return;

  function update() {
    const casePrice = parseFloat(caseInput.value) || 0;
    const keyPrice = parseFloat(keyInput.value) || 0;
    const totalCost = casePrice + keyPrice;
    if (totalCost <= 0) { results.innerHTML = '<p style="color:var(--text2);text-align:center">Enter prices above</p>'; return; }

    const avgReturn = totalCost * 0.35;
    const ev = avgReturn - totalCost;
    const roi = ((avgReturn / totalCost - 1) * 100).toFixed(1);

    results.innerHTML = `
      <div class="result-item"><div class="val">$${totalCost.toFixed(2)}</div><div class="lbl">Cost Per Open</div></div>
      <div class="result-item"><div class="val">$${avgReturn.toFixed(2)}</div><div class="lbl">Avg Return</div></div>
      <div class="result-item red"><div class="val">$${ev.toFixed(2)}</div><div class="lbl">Expected Value</div></div>
      <div class="result-item red"><div class="val">${roi}%</div><div class="lbl">ROI</div></div>
    `;
  }

  caseInput.addEventListener('input', update);
  keyInput.addEventListener('input', update);
  update();
}

document.addEventListener('DOMContentLoaded', function() {
  if (document.getElementById('case-count')) initCalc('case-count', 'calc-results');
  if (document.getElementById('ev-case-price')) initEVCalc('ev-case-price', 'ev-key-price', 'ev-results');
});
